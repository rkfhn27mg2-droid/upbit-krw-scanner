# Upbit KRW cloud scanner — research prototype

## Deployment
1. Provision a Linux VPS with outbound HTTPS and install Docker Engine + Compose plugin.
2. Upload this directory to the VPS; run `cp .env.example .env`.
3. Create a Telegram bot via @BotFather, obtain the chat ID, and populate `.env` on the VPS. Keep the token secret. Set `chmod 600 .env`.
4. Run `docker compose up -d --build` and `docker compose logs -f scanner`.
5. Inspect `data/latest.json`: only `status=COMPLETE` with matching `expected`, `daily_ok`, `four_ok`, and zero `failed` supports complete coverage.

## Important limits
- This is a deployable *prototype*, not a verified live scanner. It has not been tested against live Upbit API from this environment.
- The prototype uses **completed candles**, so reported price is the last completed daily close, **not live price**.
- The news, Upbit investment warnings, circulating supply, token unlock and BTC-relative-strength gates are **not implemented**. Never treat an alert as a final entry recommendation without these checks.
- Four-hour and daily indicators are approximations; the alert stage criteria need backtesting before live trading decisions.
- 200 candles may not span enough calendar time for thinly traded markets; candles with no trades are omitted by the exchange.
- The first successful scan alerts on all current candidates (up to 5); later scans only new candidates or upward stage transitions.
- If any market fetch fails, alerts are suppressed and state is not updated. Missing-history markets are flagged as failures.
- No private API key, balance access or order placement.
