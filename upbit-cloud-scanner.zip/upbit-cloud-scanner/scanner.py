import os, time, json, sqlite3, logging, statistics, datetime as dt
from pathlib import Path
import requests

BASE='https://api.upbit.com'; ROOT=Path('/app/data'); ROOT.mkdir(parents=True,exist_ok=True)
DB=ROOT/'state.sqlite'; LOG=ROOT/'latest.json'; S=requests.Session(); S.headers.update({'Accept':'application/json','User-Agent':'krw-research-scanner/1.0'})
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
DELAY=float(os.getenv('API_DELAY','0.17'))

def get(path,params=None):
    for attempt in range(5):
        try:
            r=S.get(BASE+path,params=params,timeout=15)
            if r.status_code in (429,500,502,503,504):
                time.sleep(min(20,2**attempt)); continue
            r.raise_for_status(); time.sleep(DELAY); return r.json()
        except (requests.RequestException,ValueError):
            if attempt==4: raise
            time.sleep(2**attempt)
    raise RuntimeError('API retry exhausted')

def ema(a,n):
    k=2/(n+1); x=a[0]; out=[]
    for v in a: x=k*v+(1-k)*x; out.append(x)
    return out

def rsi(a,n=14):
    changes=[a[i]-a[i-1] for i in range(1,len(a))]
    gains=[max(0,x) for x in changes]; losses=[max(0,-x) for x in changes]
    if len(changes)<n+2:return 50
    ag=sum(gains[:n])/n; al=sum(losses[:n])/n
    for g,l in zip(gains[n:],losses[n:]):ag=(ag*(n-1)+g)/n;al=(al*(n-1)+l)/n
    return 100 if al==0 else 100-100/(1+ag/al)

def cmf(c,n=20):
    recent=c[-n:]; den=sum(x['candle_acc_trade_volume'] for x in recent)
    if den==0:return 0
    return sum(((2*x['trade_price']-x['high_price']-x['low_price'])/(x['high_price']-x['low_price']) if x['high_price']>x['low_price'] else 0)*x['candle_acc_trade_volume'] for x in recent)/den

def prepare(raw,minutes=False):
    a=sorted(raw,key=lambda x:x['candle_date_time_utc'])
    now=dt.datetime.now(dt.timezone.utc)
    # discard unfinished daily (KST 09:00 boundary) and 4h candle (UTC 00/04/08/...)
    def closed(x):
        start=dt.datetime.fromisoformat(x['candle_date_time_utc']).replace(tzinfo=dt.timezone.utc)
        if minutes:return start+dt.timedelta(hours=4)<=now
        kst=now+dt.timedelta(hours=9); current=kst.replace(hour=9,minute=0,second=0,microsecond=0)
        if kst.hour<9:current-=dt.timedelta(days=1)
        return start<current-dt.timedelta(hours=9)
    return [x for x in a if closed(x)]

def evaluate(market,days,fours):
    if len(days)<80 or len(fours)<80:return None,'insufficient_candles'
    d=days; h=fours; close=[x['trade_price'] for x in d]; hc=[x['trade_price'] for x in h]
    if min(close)<=0:return None,'invalid_price'
    latest=d[-1]; recent=d[-5:]; base=[x['candle_acc_trade_price'] for x in d[-65:-5]]
    b=statistics.median(base) if base else 0
    if b<=0:return None,'zero_baseline'
    vol_ratio=max(x['candle_acc_trade_price'] for x in recent)/b
    recent_ratio=statistics.mean(x['candle_acc_trade_price'] for x in recent[-3:])/b
    rise=(close[-1]/close[-11]-1)*100
    bottom=min(x['low_price'] for x in d[-60:-5]); range_high=max(x['high_price'] for x in d[-60:-5])
    range_low=min(x['low_price'] for x in d[-60:-5]); range_pct=(range_high/range_low-1)*100 if range_low else 999
    tail=(latest['high_price']-max(latest['opening_price'],latest['trade_price']))/max(1e-12,latest['high_price']-latest['low_price'])
    eff=(latest['trade_price']-latest['low_price'])/max(1e-12,latest['high_price']-latest['low_price'])
    r=rsi(hc); rprev=rsi(hc[:-4]); flow=cmf(h); flowprev=cmf(h[:-4]); macd=ema(close,12)[-1]-ema(close,26)[-1]
    higher_lows=min(x['low_price'] for x in h[-4:])>min(x['low_price'] for x in h[-12:-4])
    pullback=statistics.mean(x['candle_acc_trade_price'] for x in h[-4:-1])<statistics.mean(x['candle_acc_trade_price'] for x in h[-12:-4])
    accel=h[-1]['candle_acc_trade_price']>statistics.mean(x['candle_acc_trade_price'] for x in h[-12:-1])*1.5
    resistance=max(x['high_price'] for x in h[-16:-1]); support=min(x['low_price'] for x in h[-8:]); breakout=hc[-1]>resistance and hc[-2]<=resistance
    drv=vol_ratio>=20 and max((x['trade_price']/x['opening_price']-1)*100 for x in recent if x['opening_price']>0)>=12
    quiet=range_pct<=65 or close[-6]/max(1e-12,close[-65])<0.85
    early=quiet and vol_ratio>=3 and -3<=rise<=20 and eff>=0.45 and tail<0.5 and close[-1]>bottom*1.04
    drv_early=drv and close[-1]>=max(x['high_price'] for x in recent)*0.75 and tail<0.55
    if not (early or drv_early):return None,'below_threshold'
    stage=1
    if (vol_ratio>=5 or recent_ratio>=5) and higher_lows and pullback and r>rprev and flow>flowprev and tail<0.45:stage=2
    if stage==2 and accel and breakout and eff>0.65 and tail<0.30:stage=3
    if rise>20 and not (drv and accel and higher_lows):stage=min(stage,1)
    if tail>=0.5 or close[-1]<bottom:stage=0
    if stage==0:return None,'distribution_or_breakdown'
    entry=resistance; risk=entry-support
    rr=(entry+2*risk-entry)/risk if risk>0 else 0
    if risk<=0 or risk/entry>0.14:stage=min(stage,1)
    # targets are technical projections, not predicted prices
    target1=entry+risk; target2=entry+2*risk
    return dict(market=market,pattern='DRV' if drv else 'PROM/지오드넷',stage=stage,price=close[-1],data_utc=d[-1]['candle_date_time_utc'],four_utc=h[-1]['candle_date_time_utc'],vol_multiple=round(vol_ratio,2),recent_multiple=round(recent_ratio,2),rise_pct=round(rise,2),rsi=round(r,1),cmf=round(flow,3),macd=round(macd,5),tail=round(tail,2),support=round(support,5),trigger=round(entry,5),target1=round(target1,5),target2=round(target2,5),higher_lows=higher_lows,accel=accel,rr=round(rr,2),news_checked=False,unlock_checked=False,relative_strength_checked=False,warning_checked=False),None

def notify(message):
    token=os.getenv('TELEGRAM_BOT_TOKEN'); chat=os.getenv('TELEGRAM_CHAT_ID')
    if not token or not chat:logging.warning('Telegram credentials absent; no alert sent');return False
    r=requests.post(f'https://api.telegram.org/bot{token}/sendMessage',json={'chat_id':chat,'text':message[:3900]},timeout=15);r.raise_for_status();return True

def main():
    now=dt.datetime.now(dt.timezone.utc).isoformat(); counts={'expected':None,'daily_ok':0,'four_ok':0,'failed':0,'candidates':0}; failures=[]; results=[]
    try:
        markets=[m['market'] for m in get('/v1/market/all',{'is_details':'true'}) if m['market'].startswith('KRW-')]
        counts['expected']=len(markets)
    except Exception as e:
        LOG.write_text(json.dumps({'time_utc':now,'status':'MARKET_LIST_FAILED','error':str(e),'counts':counts},ensure_ascii=False,indent=2));logging.exception('Market list unavailable');return
    for i,market in enumerate(markets,1):
        try:
            day=prepare(get('/v1/candles/days',{'market':market,'count':200}));counts['daily_ok']+=1
            four=prepare(get('/v1/candles/minutes/240',{'market':market,'count':200}),True);counts['four_ok']+=1
            candidate,reason=evaluate(market,day,four)
            if candidate:results.append(candidate)
            elif reason=='insufficient_candles':failures.append({'market':market,'reason':reason})
        except Exception as e:failures.append({'market':market,'reason':str(e)});logging.warning('%s: %s',market,e)
        if i%30==0:logging.info('progress %s/%s',i,len(markets))
    counts['failed']=len(failures);counts['candidates']=len(results)
    # Any missing data prevents a clean full-universe claim and suppresses trade alerts.
    complete=counts['daily_ok']==len(markets) and counts['four_ok']==len(markets) and not failures
    status='COMPLETE' if complete else 'PARTIAL'
    results.sort(key=lambda x:(x['stage'],x['recent_multiple'],x['vol_multiple']),reverse=True)
    conn=sqlite3.connect(DB);conn.execute('CREATE TABLE IF NOT EXISTS stages(market TEXT PRIMARY KEY,stage INTEGER,seen_utc TEXT)')
    alerts=[]
    if complete:
        for c in results:
            row=conn.execute('SELECT stage FROM stages WHERE market=?',(c['market'],)).fetchone()
            if row is None or c['stage']>row[0]:alerts.append(c)
        # Refresh only on a complete scan; disappearance resets a candidate.
        conn.execute('DELETE FROM stages')
        conn.executemany('INSERT INTO stages VALUES(?,?,?)',[(c['market'],c['stage'],now) for c in results]);conn.commit()
    conn.close()
    payload={'time_utc':now,'status':status,'counts':counts,'failures':failures,'candidates':results,'alerts':alerts,'limitations':['News, Upbit notices, unlock, supply and market relative strength not independently verified; alerts are research only','No order or portfolio access','Closed candles only; last trade price is not current quote']}
    LOG.write_text(json.dumps(payload,ensure_ascii=False,indent=2))
    logging.info('%s %s',status,counts)
    if complete:
        for c in alerts[:5]:
            stage={1:'선행 관심',2:'조건부 진입',3:'진입 확인'}[c['stage']]
            message=(f"[업비트 신규 신호] {c['market']} {stage} / {c['pattern']}\n기준 UTC {c['data_utc']} (일봉 종가, 현재가 아님)\n종가 {c['price']:g}원 / 수급 최대 {c['vol_multiple']}배 / 최근3일 {c['recent_multiple']}배 / 10일 변화 {c['rise_pct']}%\n4시간 RSI {c['rsi']} CMF {c['cmf']}\n진입 검증: {c['trigger']:g}원 돌파·유지 및 수급 재가속\n무효화 참고: {c['support']:g}원 이탈\n기술 목표: {c['target1']:g} / {c['target2']:g}원 (2차는 거래대금 유지·고점 상승 때만)\n추격 및 윗꼬리 위험 주의. 공지·언락·뉴스 미검증: 매수 확정 아님.")
            try:notify(message)
            except Exception:logging.exception('Telegram delivery failed')

if __name__=='__main__':main()
